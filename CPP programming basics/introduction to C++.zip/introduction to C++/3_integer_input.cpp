#include <iostream>
using namespace std;

int main() {
    int a, b ,c;
    cin>> a >> b>> c ;
    cout << "Here are these 3 int numbers : "<< endl;
    cout <<a << endl;
    cout <<b << endl;
    cout <<c << endl;
}