#include <iostream>
using namespace std;

int main() {
    double a, b ,c, d, e;
    cin>> a >> b >> c >> d >> e;
    cout << "Here are these 5 float numbers : "<< endl;
    cout <<a << endl;
    cout <<b << endl;
    cout <<c << endl;
    cout <<d << endl;
    cout <<e << endl;
}