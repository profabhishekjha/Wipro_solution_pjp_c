#include <iostream>
using namespace std;

int main(){
    int cashType_1 = 10;
    int cashType_2 = 50;
    int cashType_3 = 100;
    int n;
    cin>> n;
    cout<< n/cashType_1<<" notes of 10 " << endl;
    cout<< n/cashType_2<<" notes of 50 " << endl;
    cout<< n/cashType_3<<" notes of 100" << endl;

}