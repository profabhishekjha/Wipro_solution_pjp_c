#include <iostream>
using namespace std;
int main(){
    int a, b;
    cout << "Enter the Numbers: " << endl;
    cin >> a >> b;
    int sum = a+b;
    int difference = a-b;

    cout << "Sum of the two numbers is "<< sum << endl;
    cout << "Difference of the two numbers is "<< difference;
} 