#include <iostream>
using namespace std;

int main(){
    int num_1, num_2, GREATER;
    cin >> num_1>> num_2;
    GREATER = (num_1 > num_2) ? num_1 : num_2;
    cout << GREATER ;
}

