#include <iostream>
using namespace std;

int main() {
    int a,b,c,d,e;
    cin >> a >>b >>c >>d >>e;
    int average = (a+b+c+d+e)/5;
    cout << average << endl;
}